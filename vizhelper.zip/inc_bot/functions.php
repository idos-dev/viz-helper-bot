<?php

function botMessage($message) {
  global $ver, $chat_id, $boticon;
  $text=hex2bin($boticon).' '.$ver.' | '.$message;
  if ($boticon=="") {
      $text=$message;
  }
  $tosend = array(
     'text' => $text,
     'parse_mode' => 'Markdown',
     'disable_web_page_preview' => 'true'
  );
  $tosend['chat_id'] = $chat_id;

  requestToTelegram($tosend);
}

function botDelMessage($message_id) {
  global $chat_id;
  $tosend = array(
     'message_id' => $message_id
  );
  $tosend['chat_id'] = $chat_id;

  requestToTelegram($tosend, "deleteMessage");
}

function botKeyboard($text, $keyboard) {
  global $chat_id;
  $tosend = array(
     'reply_markup' => $keyboard,
     'parse_mode' => 'Markdown',
     'disable_web_page_preview' => 'false'
  );
  if ($text<>"") {$tosend['text'] = $text;}
  $tosend['chat_id'] = $chat_id;

  requestToTelegram($tosend);
}


//отправка ответа в чат Телеграм
function requestToTelegram($data, $type = 'sendMessage') {
  if( $curl = curl_init() ) {
    curl_setopt($curl, CURLOPT_URL, API_URL . $type);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_POST, TRUE);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_exec($curl);
    curl_close($curl);
  }
}

function vizAccountInfo($whois, $param = NULL) {
// Запрос информации об аккаунте без @
    $whois=str_replace("@", "", $whois); //mb_substr($whois, 1)
// возможен множественный запрос через запятую.
    $whois=str_replace(",", "\",\"", $whois); //mb_substr($whois, 1)
    $whois="\"".$whois."\"";

    $req = '{"id":24, "jsonrpc":"2.0","method":"call","params":["database_api","get_accounts",[['.$whois.']]]}';
    $GLOBALS['client']->send($req);
    $viz_resp = $GLOBALS['client']->receive();

    $resp_object = json_decode($viz_resp);

    if (!empty($resp_object)) {
       if (is_null($param)) {
// возвращаем массив параметров
          return $resp_object->result;
       } else {
// возвращаем значение параметра (не рекомендуется для получения нескольких параметров - каждый раз дёргается нода)
          return $resp_object->result[0][$param];
       }
    }
    return FALSE;
} // vizAccountInfo

?>
